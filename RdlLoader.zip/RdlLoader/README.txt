How To Create a Compiled RDL Installer

1. You must have the .Net Framework SDK 2.0 installed

2. Check your SQL and RDL files into Source Control. 
   Never deliver reports or SQL scripts until you've checked them into Source Control!

3. Copy RDL and SQL files into the RDL and SQL folders respectively. 
   The RDL files will be deleted during Step 5, so make sure you did Step 2.
   SQL files are executed in alphabetical order. So if you need them executed in
   a particular order, name them accordingly.
   SQL transactions are split by "GO" being on a line by itself.

4. Run "CreateRdlLoader.bat"

5. Test "RdlLoader.exe". 
   You can rename the executable. For example, you may find it easier to keep it straight
   to rename this file to the client's copy number. 

6. Send the client "RdlLoader.exe".