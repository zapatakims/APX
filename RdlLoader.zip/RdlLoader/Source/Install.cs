using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RdlLoader
{
    public partial class Install : Form
    {
        Installer Installer;
        Boolean HasBeenRunOnce = false;
        public Install(Installer installer)
        {
            this.Installer = installer;
            this.StartPosition = FormStartPosition.Manual;
            InitializeComponent();
            
        }

        private ReportService.ReportingService2005 ConnectToSsrsServer()
        {
            ReportService.ReportingService2005 rs = new RdlLoader.ReportService.ReportingService2005();
            try
            {
                rs = new RdlLoader.ReportService.ReportingService2005();
                if (Installer.SsrsUseWindowsAuth)
                {
                    rs.UseDefaultCredentials = true;
                }
                else
                {
                    if (Installer.SsrsDomain.Trim().Length > 0)
                    {
                        rs.Credentials = new System.Net.NetworkCredential(Installer.SsrsUsername, Installer.SsrsPassword, Installer.SsrsDomain);
                    }
                    else
                    {
                        rs.Credentials = new System.Net.NetworkCredential(Installer.SsrsUsername, Installer.SsrsPassword);
                    }
                }

                rs.Url = Installer.SsrsServerUrl + "/ReportService2005.asmx";
            }
            catch (Exception ex)
            {
                throw new Exception("Error creating connection to SSRS server: " + ex.Message);
            }
            return rs;
        }

        private void bgUpdatingWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                double currentItem = 0;
                double totalItems = Installer.ReportDefinitions.Count + Installer.SqlScripts.Count;

                if (Installer.SqlScripts.Count > 0)
                {
                    bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Connecting to SQL Server");
                    string scriptName = "Connection Error";
                    try
                    {
                        string connectionString = "Data Source=" + Installer.SqlServer;
                        connectionString += ";Initial Catalog=" + Installer.SqlDatabase;
                        if (Installer.SqlUseWindowsAuth)
                        {
                            connectionString += ";Integrated Security=SSPI";
                        }
                        else
                        {
                            connectionString += ";User ID=" + Installer.SqlUsername;
                            connectionString += ";Password=" + Installer.SqlPassword;
                        }
                        connectionString += ";Provider=SQLOLEDB;";
                        System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection(connectionString);

                        conn.Open();
                        for (int i = 0; i < Installer.SqlScripts.Count; i++)
                        {
                            currentItem++;
                            scriptName = Installer.SqlScripts.Keys[i];
                            string scriptText = Installer.SqlScripts.Values[i];
                            bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Starting SQL script: " + scriptName);
                            string[] sqlTransactions = scriptText.Split(new string[] { "go\n", "GO\n", "Go\n", "gO\n" }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string sqlTransaction in sqlTransactions)
                            {
                                using (System.Data.OleDb.OleDbCommand command = conn.CreateCommand())
                                {
                                    command.CommandText = sqlTransaction;
                                    command.Transaction = conn.BeginTransaction();
                                    command.ExecuteNonQuery();
                                    command.Transaction.Commit();
                                }
                            }
                            bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Completed SQL script: " + scriptName);
                        }
                        conn.Dispose();
                                               
                    }
                    catch (Exception sqlException)
                    {
                        bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Error running SQL script: " + scriptName);
                        throw sqlException;
                    }
                }
                
                if (Installer.ReportDefinitions.Count > 0) 
                {
                    bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Connecting to SSRS server ");
                    ReportService.ReportingService2005 rs = ConnectToSsrsServer();

                    for (int i = 0; i < Installer.ReportDefinitions.Keys.Count; i++)
                    {
                        string reportName = Installer.ReportDefinitions.Keys[i];
                        try 
                        {                            
                            
                            string reportFolder = Installer.SsrsReportFolder;
                            
                            currentItem++;
                            bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Starting " + reportName);
                            
                            if (!reportFolder.StartsWith("/"))
                            {
                                reportFolder = "/" + reportFolder;
                            }
                            rs.CreateReport(reportName, reportFolder, true, Installer.ReportDefinitions[reportName], new RdlLoader.ReportService.Property[0]);
                        }
                        catch (Exception reportException) 
                        {
                            bgUpdatingWorker.ReportProgress(Convert.ToInt32(currentItem / totalItems * 100d), "Error updating " + reportName);
                            throw reportException;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                e.Result = new Exception("An error occurred during installation: " + ex.Message);
            }
            bgUpdatingWorker.ReportProgress(100);
        }

        private void bgUpdatingWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pgUpdateProgress.Value = e.ProgressPercentage;
            if (e.UserState != null)
            {
                rtbInstallText.AppendText("\n" + e.UserState.ToString());
            }
        }

        private void bgUpdatingWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            btnFinish.Enabled = true;
            HasBeenRunOnce = true;
            rtbInstallText.AppendText("\nUpdate process finished.");

            if (e.Result != null)
            {
                Exception ex = (Exception)e.Result;
                rtbInstallText.AppendText("\nUpdate was NOT successful.");
                rtbInstallText.AppendText("\nError: " + ex.Message);
                btnPrevious.Enabled = true;
                btnRetry.Enabled = true;
            }
        }

        private void Form_Shown(object sender, EventArgs e)
        {
            StartWorker(false);
        }

        private void btnUpdateReports_Click(object sender, EventArgs e)
        {
            Installer.GetNextForm();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            Installer.GetPreviousForm();
        }

        private void Install_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Install_Activated(object sender, EventArgs e)
        {
            StartWorker(false);
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {
            StartWorker(true);
        }
        private void StartWorker(bool ForceRetry)
        {
            if (!bgUpdatingWorker.IsBusy)
            {
                if (ForceRetry || Installer.RunInstaller)
                {
                    Installer.RunInstaller = false;
                    btnFinish.Enabled = false;
                    btnPrevious.Enabled = false;
                    btnRetry.Enabled = false;
                    rtbInstallText.Text = "Beginning update process at " + DateTime.Now.ToShortTimeString();
                    bgUpdatingWorker.RunWorkerAsync();
                }
            }
        }

        private void rtbInstallText_TextChanged(object sender, EventArgs e)
        {
            
        }

    }
}