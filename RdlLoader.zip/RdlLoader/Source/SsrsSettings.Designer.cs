namespace RdlLoader
{
    partial class SsrsSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSsrsServer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtApxFolder = new System.Windows.Forms.TextBox();
            this.btnUpdateReports = new System.Windows.Forms.Button();
            this.chkUseWindowsSecurity = new System.Windows.Forms.CheckBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtDomain = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtSsrsServer
            // 
            this.txtSsrsServer.Location = new System.Drawing.Point(100, 19);
            this.txtSsrsServer.Name = "txtSsrsServer";
            this.txtSsrsServer.Size = new System.Drawing.Size(231, 20);
            this.txtSsrsServer.TabIndex = 0;
            this.txtSsrsServer.TextChanged += new System.EventHandler(this.txtSsrsServer_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "APX Folder";
            // 
            // txtApxFolder
            // 
            this.txtApxFolder.Location = new System.Drawing.Point(100, 45);
            this.txtApxFolder.Name = "txtApxFolder";
            this.txtApxFolder.Size = new System.Drawing.Size(231, 20);
            this.txtApxFolder.TabIndex = 1;
            this.txtApxFolder.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btnUpdateReports
            // 
            this.btnUpdateReports.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateReports.Location = new System.Drawing.Point(256, 187);
            this.btnUpdateReports.Name = "btnUpdateReports";
            this.btnUpdateReports.Size = new System.Drawing.Size(74, 23);
            this.btnUpdateReports.TabIndex = 6;
            this.btnUpdateReports.Text = "Next";
            this.btnUpdateReports.UseVisualStyleBackColor = true;
            this.btnUpdateReports.Click += new System.EventHandler(this.button1_Click);
            // 
            // chkUseWindowsSecurity
            // 
            this.chkUseWindowsSecurity.AutoSize = true;
            this.chkUseWindowsSecurity.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkUseWindowsSecurity.Checked = true;
            this.chkUseWindowsSecurity.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUseWindowsSecurity.Location = new System.Drawing.Point(12, 71);
            this.chkUseWindowsSecurity.Name = "chkUseWindowsSecurity";
            this.chkUseWindowsSecurity.Size = new System.Drawing.Size(184, 17);
            this.chkUseWindowsSecurity.TabIndex = 2;
            this.chkUseWindowsSecurity.Text = "Use Windows Integrated Security";
            this.chkUseWindowsSecurity.UseVisualStyleBackColor = true;
            this.chkUseWindowsSecurity.CheckedChanged += new System.EventHandler(this.chkUseWindowsSecurity_CheckedChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Enabled = false;
            this.txtPassword.Location = new System.Drawing.Point(100, 146);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(231, 20);
            this.txtPassword.TabIndex = 5;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Username";
            // 
            // txtUsername
            // 
            this.txtUsername.Enabled = false;
            this.txtUsername.Location = new System.Drawing.Point(100, 120);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(231, 20);
            this.txtUsername.TabIndex = 4;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Password";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Location = new System.Drawing.Point(12, 187);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Previous";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtDomain
            // 
            this.txtDomain.Enabled = false;
            this.txtDomain.Location = new System.Drawing.Point(100, 94);
            this.txtDomain.Name = "txtDomain";
            this.txtDomain.Size = new System.Drawing.Size(231, 20);
            this.txtDomain.TabIndex = 3;
            this.txtDomain.TextChanged += new System.EventHandler(this.txtDomain_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Domain";
            // 
            // SsrsSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 222);
            this.Controls.Add(this.txtDomain);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chkUseWindowsSecurity);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.btnUpdateReports);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtApxFolder);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSsrsServer);
            this.Name = "SsrsSettings";
            this.Text = "SSRS Settings";
            this.Activated += new System.EventHandler(this.SsrsSettings_Activate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SsrsSettings_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSsrsServer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtApxFolder;
        private System.Windows.Forms.Button btnUpdateReports;
        private System.Windows.Forms.CheckBox chkUseWindowsSecurity;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtDomain;
        private System.Windows.Forms.Label label5;
    }
}

