using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RdlLoader
{
    public partial class Contents : Form
    {
        Installer Installer;
        public Contents(Installer installer)
        {
            this.Installer = installer;


            InitializeComponent();
        }
        private void Contents_Load(object sender, EventArgs e)
        {
            rtbInstallOverview.Text = "The following items will be installed or upgraded:";

            if (Installer.SqlScripts.Count > 0)
            {
                rtbInstallOverview.Text += "\n\n\tSql Scripts:";
                foreach (string sqlName in Installer.SqlScripts.Keys)
                {
                    rtbInstallOverview.Text += "\n\t\t" + sqlName;
                }
            }

            if (Installer.ReportDefinitions.Count > 0)
            {
                rtbInstallOverview.Text += "\n\n\tSSRS Reports:";
                foreach (string reportName in Installer.ReportDefinitions.Keys)
                {
                    rtbInstallOverview.Text += "\n\t\t" + reportName;
                }
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Installer.GetNextForm();
        }

        private void Contents_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

    }
}