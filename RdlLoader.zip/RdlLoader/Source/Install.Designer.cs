namespace RdlLoader
{
    partial class Install
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFinish = new System.Windows.Forms.Button();
            this.pgUpdateProgress = new System.Windows.Forms.ProgressBar();
            this.bgUpdatingWorker = new System.ComponentModel.BackgroundWorker();
            this.toolTipProvider = new System.Windows.Forms.ToolTip(this.components);
            this.rtbInstallText = new System.Windows.Forms.RichTextBox();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnRetry = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFinish
            // 
            this.btnFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFinish.Enabled = false;
            this.btnFinish.Location = new System.Drawing.Point(233, 190);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(74, 23);
            this.btnFinish.TabIndex = 0;
            this.btnFinish.Text = "Exit Setup";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnUpdateReports_Click);
            // 
            // pgUpdateProgress
            // 
            this.pgUpdateProgress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pgUpdateProgress.Location = new System.Drawing.Point(12, 161);
            this.pgUpdateProgress.Name = "pgUpdateProgress";
            this.pgUpdateProgress.Size = new System.Drawing.Size(294, 23);
            this.pgUpdateProgress.TabIndex = 10;
            // 
            // bgUpdatingWorker
            // 
            this.bgUpdatingWorker.WorkerReportsProgress = true;
            this.bgUpdatingWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgUpdatingWorker_DoWork);
            this.bgUpdatingWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgUpdatingWorker_RunWorkerCompleted);
            this.bgUpdatingWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgUpdatingWorker_ProgressChanged);
            // 
            // rtbInstallText
            // 
            this.rtbInstallText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbInstallText.Location = new System.Drawing.Point(12, 8);
            this.rtbInstallText.Name = "rtbInstallText";
            this.rtbInstallText.ReadOnly = true;
            this.rtbInstallText.Size = new System.Drawing.Size(293, 147);
            this.rtbInstallText.TabIndex = 11;
            this.rtbInstallText.Text = "";
            this.rtbInstallText.TextChanged += new System.EventHandler(this.rtbInstallText_TextChanged);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrevious.Enabled = false;
            this.btnPrevious.Location = new System.Drawing.Point(12, 190);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(74, 23);
            this.btnPrevious.TabIndex = 2;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnRetry
            // 
            this.btnRetry.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRetry.Enabled = false;
            this.btnRetry.Location = new System.Drawing.Point(153, 190);
            this.btnRetry.Name = "btnRetry";
            this.btnRetry.Size = new System.Drawing.Size(74, 23);
            this.btnRetry.TabIndex = 1;
            this.btnRetry.Text = "Retry";
            this.btnRetry.UseVisualStyleBackColor = true;
            this.btnRetry.Click += new System.EventHandler(this.btnRetry_Click);
            // 
            // Install
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 223);
            this.Controls.Add(this.btnRetry);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.rtbInstallText);
            this.Controls.Add(this.pgUpdateProgress);
            this.Controls.Add(this.btnFinish);
            this.Name = "Install";
            this.Text = "Installing";
            this.Shown += new System.EventHandler(this.Form_Shown);
            this.Activated += new System.EventHandler(this.Install_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Install_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.ProgressBar pgUpdateProgress;
        private System.ComponentModel.BackgroundWorker bgUpdatingWorker;
        private System.Windows.Forms.ToolTip toolTipProvider;
        private System.Windows.Forms.RichTextBox rtbInstallText;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnRetry;
    }
}

