using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace RdlLoader
{
    public class Installer
    {

        Assembly assembly = Assembly.GetExecutingAssembly();
        public SortedList<string, byte[]> ReportDefinitions = new SortedList<string, byte[]>();
        public SortedList<string, string> SqlScripts = new SortedList<string, string>();
        SortedList<string, byte[]> GetReports()
        {
            SortedList<string, byte[]> reports = new SortedList<string, byte[]>();
            try
            {
                
                string[] resourceNames = assembly.GetManifestResourceNames();
                foreach (string resourcename in resourceNames)
                {
                    if (resourcename.EndsWith("rdl", StringComparison.CurrentCultureIgnoreCase))
                    {
                        string reportName = resourcename.Substring(0, resourcename.Length - 4);
                        reportName = reportName.Replace("RdlLoader.", "");

                        List<byte> reportDefinition = new List<byte>();

                        using (System.IO.BinaryReader br = new System.IO.BinaryReader(assembly.GetManifestResourceStream(resourcename)))
                        {
                            while (br.PeekChar() > -1)
                            {
                                reportDefinition.Add(br.ReadByte());
                            }
                        }

                        reports.Add(reportName, reportDefinition.ToArray());
                    }
                }
            }
            catch { }
            return reports;
            
        }
        SortedList<string, string> GetSqlScripts()
        {

            SortedList<string, string> sqlscripts = new SortedList<string, string>();
            
            try
            {

                string[] resourceNames = assembly.GetManifestResourceNames();
                foreach (string resourcename in resourceNames)
                {
                    if (resourcename.EndsWith("sql", StringComparison.CurrentCultureIgnoreCase))
                    {

                        string sqlName = resourcename.Replace("RdlLoader.", "");
                        string sqlText = "";
                        using (System.IO.StreamReader sr = new System.IO.StreamReader(assembly.GetManifestResourceStream(resourcename), true))
                        {
                            while (sr.Peek() > -1)
                            {
                                sqlText += sr.ReadLine().Trim() +  "\n";
                            }
                        }

                        sqlscripts.Add(sqlName, sqlText);
                    }
                }
            }
            catch { }



            return sqlscripts;
            
        }
        List<System.Windows.Forms.Form> forms = new List<System.Windows.Forms.Form>();
        public Dictionary<DateTime, string> Errors = new Dictionary<DateTime, string>();

        public Installer()
        {
            ReportDefinitions = GetReports();
            SqlScripts = GetSqlScripts();
            forms.Add(new Contents(this));
            if (SqlScripts.Count > 0)
            {
                forms.Add(new SqlSettings(this));
            }
            if (ReportDefinitions.Count > 0)
            {
                forms.Add(new SsrsSettings(this));
            }
            if (forms.Count > 1)
            {
                forms.Add(new Install(this));
            }

            foreach (System.Windows.Forms.Form f in forms)
            {
                f.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            }

        }
        private int enumerator = -1;
        public System.Windows.Forms.Form GetNextForm() 
        {
            return GetForm(true);
        }
        private System.Windows.Forms.Form GetForm(bool IsNext)
        {
            int increment = -1;
            if (IsNext)
            {
                increment = 1;
            }
            System.Windows.Forms.Form OldForm = null;
            System.Windows.Forms.Form NewForm = null;
            //Load existing form
            if (enumerator > -1)
            {
                OldForm = forms[enumerator];
            }

            enumerator += increment;

            if (enumerator < forms.Count)
            {
                NewForm = forms[enumerator];
            }

            if (enumerator < 0 || enumerator >= forms.Count)
            {
                System.Windows.Forms.Application.Exit();
            }

            if (OldForm != null && NewForm != null)
            {
                NewForm.Height = OldForm.Height;
                NewForm.Width = OldForm.Width;
                NewForm.WindowState = OldForm.WindowState;
                NewForm.Location = OldForm.Location;

                NewForm.Show();
                OldForm.Hide();
            }
            return NewForm;
            
        }
        public System.Windows.Forms.Form GetPreviousForm()
        {
            return GetForm(false);
        }

        private string ssrsServerUrl = "http://localhost/reportserver";
        public string SsrsServerUrl
        {
            get { return ssrsServerUrl; }
            set
            {
                ssrsServerUrl = value;
                while (ssrsServerUrl.EndsWith("/"))
                {
                    ssrsServerUrl = ssrsServerUrl.Substring(0, ssrsServerUrl.Length - 1);
                }
            }
        }
        public bool SsrsUseWindowsAuth = true;
        public string SsrsUsername = "";
        public string SsrsPassword = "";
        public string SsrsDomain = "";
        public String SsrsReportFolder = "Advent-APXFirm";

        public bool SqlUseWindowsAuth = true;
        public string SqlServer = "localhost";
        public string SqlUsername = "sa";
        public string SqlPassword = "";
        public string SqlDatabase = "ApxFirm";
        public bool RunInstaller = true;
    }
    

}
