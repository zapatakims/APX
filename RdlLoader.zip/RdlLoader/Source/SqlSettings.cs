using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RdlLoader
{
    public partial class SqlSettings : Form
    {
        Installer Installer;
        public SqlSettings(Installer installer)
        {
            this.Installer = installer;        
            InitializeComponent();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            Installer.GetPreviousForm();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Installer.GetNextForm();
        }

        private void SqlSettings_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void chkUseWindowsSecurity_CheckedChanged(object sender, EventArgs e)
        {
            Installer.SqlUseWindowsAuth = chkUseWindowsSecurity.Checked;
            txtPassword.Enabled = !chkUseWindowsSecurity.Checked;
            txtUsername.Enabled = !chkUseWindowsSecurity.Checked;
        }

        private void txtSqlServer_TextChanged(object sender, EventArgs e)
        {
            Installer.SqlServer = txtSqlServer.Text;
        }

        private void txtApxDatabase_TextChanged(object sender, EventArgs e)
        {
            Installer.SqlDatabase = txtApxDatabase.Text;
        }
        

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            Installer.SqlUsername = txtUsername.Text;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            Installer.SqlPassword = txtPassword.Text;
        }

        private void SqlSettings_Activated(object sender, EventArgs e)
        {
            Installer.RunInstaller = true;
            txtApxDatabase.Text = Installer.SqlDatabase;
            txtPassword.Text = Installer.SqlPassword;
            txtSqlServer.Text = Installer.SqlServer;
            txtUsername.Text = Installer.SqlUsername;
            chkUseWindowsSecurity.Checked = Installer.SqlUseWindowsAuth;
        }
    }
}