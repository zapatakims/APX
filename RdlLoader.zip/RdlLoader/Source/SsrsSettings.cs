using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RdlLoader
{
    public partial class SsrsSettings : Form
    {
        Installer Installer;
        public SsrsSettings(Installer installer)
        {
            this.Installer = installer;

            InitializeComponent();
            
        }

        private void chkUseWindowsSecurity_CheckedChanged(object sender, EventArgs e)
        {
            Installer.SsrsUseWindowsAuth = chkUseWindowsSecurity.Checked;
            txtDomain.Enabled = !chkUseWindowsSecurity.Checked;
            txtPassword.Enabled = !chkUseWindowsSecurity.Checked;
            txtUsername.Enabled = !chkUseWindowsSecurity.Checked;
        }

        private void SsrsSettings_Activate(object sender, EventArgs e)
        {
            Installer.RunInstaller = true;
            txtApxFolder.Text = Installer.SsrsReportFolder;
            txtDomain.Text = Installer.SsrsDomain;
            txtPassword.Text = Installer.SsrsPassword;
            txtSsrsServer.Text = Installer.SsrsServerUrl;
            txtUsername.Text = Installer.SsrsUsername;
            chkUseWindowsSecurity.Checked = Installer.SsrsUseWindowsAuth;
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            Installer.SsrsUsername = txtUsername.Text;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            Installer.SsrsPassword = txtPassword.Text;
        }

        private void txtSsrsServer_TextChanged(object sender, EventArgs e)
        {
            Installer.SsrsServerUrl = txtSsrsServer.Text;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Installer.SsrsReportFolder = txtApxFolder.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Installer.GetNextForm();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Installer.GetPreviousForm();
        }

        private void txtDomain_TextChanged(object sender, EventArgs e)
        {
            Installer.SsrsDomain = txtDomain.Text;
        }

        private void SsrsSettings_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}